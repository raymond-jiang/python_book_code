# tequila
Tequila is a website contributed to give answers to rookies
* Using Python3
* Bulding with Tornado 5
* Using MySQL 5.7
* Using Asynchronous IO programming
* Using Multiple threading for database connection
* Using Multiple process for high performence
* Bulding a Django-like startup for project
