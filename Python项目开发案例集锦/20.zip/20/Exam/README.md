# examination

* Offer a platform to take a skill quizz
* Rank users who participate in the quizz and give them suggestions for career
* Help organizations to make out questions for interviewee
* Using Django 1.11.2 Python3.5 and MySQL5.7 Bootstrap3
* the site is under building http://www.quizz.cn and the source code places here
