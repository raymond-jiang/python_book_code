# -*- coding: utf-8 -*-


def index(request):
    pass
